package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.chart.XYChart;
import javafx.fxml.Initializable;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class GridConsumptionController implements Initializable {

    @FXML
    private LineChart<String, Number> consumptionChart;

    @FXML
    private Button exportButton;

    @FXML
    private Button settingsButton;

    @FXML
    private Button refreshButton;

    @FXML
    private Button ReturnButton;

    @FXML
    private Label statusLabel;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setupChart();
        setupButtonHandlers();
        updateStatus();
    }

    private void setupChart() {
        // Create a series for the line chart
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Power Consumption");

        // Retrieve the logged-in user's location
        User user = Session.getLoggedInUser();
        String location = user.getCity();

        // Fetch grid consumption data for the user's location
        GridConsumptionDatabase database = new GridConsumptionDatabase();
        List<GridConsumption> gridData = database.getGridConsumptionByLocation(location);

        // Add the grid consumption data to the series
        for (GridConsumption gc : gridData) {
            series.getData().add(new XYChart.Data<>(gc.getDate().toString(), gc.getConsumptionKWh()));
        }

        // Add series to chart
        consumptionChart.getData().add(series);

        // Style the chart
        consumptionChart.setCreateSymbols(true);
        consumptionChart.setAnimated(false);
    }

    private void setupButtonHandlers() {
        exportButton.setOnAction(event -> handleExport());
        settingsButton.setOnAction(event -> handleSettings());
        refreshButton.setOnAction(event -> handleRefresh());
    }

    private void handleExport() {
        // Implement export functionality
        System.out.println("Exporting data...");

    }

    private void handleSettings() {
        // Implement settings functionality
        System.out.println("Opening settings...");
    }

    private void handleRefresh() {
        // Refresh the data
        updateChartData();
        updateStatus();
    }

    private void updateChartData() {
        // Clear existing data
        consumptionChart.getData().clear();

        // Retrieve the logged-in user's location again
        User user = Session.getLoggedInUser();
        String location = user.getCity();

        // fetch grid consumption data for the user's location
        GridConsumptionDatabase database = new GridConsumptionDatabase();
        List<GridConsumption> gridData = database.getGridConsumptionByLocation(location);

        // Create a new series for updated data
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        for (GridConsumption gc : gridData) {
            series.getData().add(new XYChart.Data<>(gc.getDate().toString(), gc.getConsumptionKWh()));
        }

        // add the updated series to the chart
        consumptionChart.getData().add(series);
    }

    private void updateStatus() {
        // update the status label with current time
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        statusLabel.setText("Last updated: " + now.format(formatter));
    }


    public void updateConsumptionData(double currentUsage, double dailyTotal, double monthlyCost) {
        // Update the UI with new values
        updateChartData();
        updateStatus();
    }

    @FXML
    private void gobacktoSolarDashboard() {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("dashboard.fxml"));
        Parent root = null;
        try {
            root = loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stage = (Stage) ReturnButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

}
