package com.example.demo3;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

//public class Weather {
//
//    private static final String API_KEY = "33H2q9uu25cyd97EKbt19g2x1iSrPa8Q"; // Replace with your valid Tomorrow.io API key
//    private static final String API_URL = "https://api.tomorrow.io/v4/weather/forecast";
//
//    public static double getSolarPotential(double latitude, double longitude) {
//        try {
//            // Construct the URL
//            String urlString = API_URL + "?location=" + latitude + "," + longitude + "&apikey=" + API_KEY;
//
//            // Open the connection
//            URL url = new URL(urlString);
//            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//            conn.setRequestMethod("GET");
//
//            // Check response code
//            int responseCode = conn.getResponseCode();
//            if (responseCode != 200) {
//                throw new RuntimeException("HTTP Response Code: " + responseCode);
//            }
//
//            // Read the response
//            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//            StringBuilder response = new StringBuilder();
//            String line;
//            while ((line = in.readLine()) != null) {
//                response.append(line);
//            }
//            in.close();
//
//            // Parse JSON response
//            JSONObject jsonResponse = new JSONObject(response.toString());
//            JSONObject timelines = jsonResponse.getJSONObject("timelines");
//            JSONArray hourlyData = timelines.getJSONArray("hourly");
//
//            // Accumulate solar potential
//            double totalUvIndex = 0;
//            int count = 0;
//
//            // Loop through hourly data
//            for (int i = 0; i < hourlyData.length(); i++) {
//                JSONObject interval = hourlyData.getJSONObject(i);
//                JSONObject values = interval.getJSONObject("values");
//
//                // Extract UV index and add if during the day
//                double uvIndex = values.optDouble("uvIndex", 0);
//                String time = interval.getString("time");
//                int hour = Integer.parseInt(time.substring(11, 13)); // Extract hour
//
//                if (hour >= 6 && hour <= 18) { // Daytime hours
//                    totalUvIndex += uvIndex;
//                    count++;
//                }
//            }
//
//            // Calculate average UV index
//            double averageUvIndex = count > 0 ? totalUvIndex / count : 0;
//            System.out.println("Average UV Index (06:00 - 18:00): " + averageUvIndex);
//
//            return averageUvIndex;
//
//        } catch (Exception e) {
//            System.err.println("Error fetching solar potential: " + e.getMessage());
//        }
//        return 0.0; // Default value in case of failure
//    }
//    public static double calculateEffectiveSunlightHours(double averageUvIndex, double averageCloudCover) {
//        // Constants
//        double maxDaylightHours = 12.0; // Assume 12 hours of daylight for simplicity
//        double maxUvIndex = 10.0; // Typical maximum UV Index
//
//        // Calculate UV Intensity Factor
//        double uvIntensityFactor = averageUvIndex / maxUvIndex;
//
//        // Calculate Cloud Adjustment Factor
//        double cloudAdjustmentFactor = 1.0 - (averageCloudCover / 100.0);
//
//        // Calculate Effective Sunlight Hours
//        return maxDaylightHours * uvIntensityFactor * cloudAdjustmentFactor;
//    }
//
//
//}
public class Weather {
    private static final String API_KEY = "33H2q9uu25cyd97EKbt19g2x1iSrPa8Q";
    private static final String API_URL = "https://api.tomorrow.io/v4/weather/forecast";

    public static double getSolarPotential(double latitude, double longitude) {
        try {
            // Existing API connection code remains the same
            String urlString = API_URL + "?location=" + latitude + "," + longitude + "&apikey=" + API_KEY;
            // ... [connection code remains unchanged]


           // Open the connection
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            // Check response code
            int responseCode = conn.getResponseCode();
            if (responseCode != 200) {
                throw new RuntimeException("HTTP Response Code: " + responseCode);
            }

            // Read the response
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                response.append(line);
            }
            in.close();

            JSONObject jsonResponse = new JSONObject(response.toString());
            JSONObject timelines = jsonResponse.getJSONObject("timelines");
            JSONArray hourlyData = timelines.getJSONArray("hourly");

            double totalUvIndex = 0;
            int count = 0;

            // Modified time window and UV calculation
            for (int i = 0; i < hourlyData.length(); i++) {
                JSONObject interval = hourlyData.getJSONObject(i);
                JSONObject values = interval.getJSONObject("values");

                double uvIndex = values.optDouble("uvIndex", 0);
                String time = interval.getString("time");
                int hour = Integer.parseInt(time.substring(11, 13));

                // Adjust time window for more accurate sunlight hours
                // For Karachi's latitude, peak sunlight is typically between 7:00 and 17:00
                if (hour >= 7 && hour <= 17) {
                    // Apply weight factor based on time of day
                    double timeWeight = 1.0;
                    if (hour < 9 || hour > 15) {
                        timeWeight = 0.7; // Lower weight for early morning and late afternoon
                    }
                    totalUvIndex += (uvIndex * timeWeight);
                    count++;
                }
            }

            double averageUvIndex = count > 0 ? totalUvIndex / count : 0;
            System.out.println("Average UV Index (07:00 - 17:00): " + averageUvIndex);
            return averageUvIndex;

        } catch (Exception e) {
            System.err.println("Error fetching solar potential: " + e.getMessage());
            return 5.0; // Default to typical UV index for Karachi if API fails
        }
    }



    public static double calculateEffectiveSunlightHours(double averageUvIndex, double averageCloudCover) {
        // Adjusted constants for Karachi's climate
        double maxDaylightHours = 10.0; // Typical peak sunlight hours in Karachi
        double maxUvIndex = 11.0; // Maximum UV Index typically observed in Karachi

        // Improved UV Intensity calculation
        double uvIntensityFactor = Math.min(averageUvIndex / maxUvIndex, 1.0);

        // More realistic cloud impact calculation
        double cloudAdjustmentFactor = 1.0 - (averageCloudCover / 200.0); // Reduced impact of cloud cover

        // Apply regional adjustment for Karachi
        double regionalAdjustment = 0.85; // Account for atmospheric conditions

        // Calculate Effective Sunlight Hours
        double effectiveSunlightHours = maxDaylightHours * uvIntensityFactor * cloudAdjustmentFactor * regionalAdjustment;

        // Ensure result is within realistic bounds for Karachi
        return Math.max(Math.min(effectiveSunlightHours, 10.0), 6.0);
    }


    public static double predictSolarPotential(String date) {
        // Simulate UV index based on month for predictions
        String month = date.substring(5, 7); // Extract month from "YYYY-MM-DD"

        // Typical UV patterns for Karachi by month
        double baseUvIndex = switch(month) {
            case "12", "01", "02" -> 6.0;  // Winter
            case "03", "04", "05" -> 9.0;  // Spring
            case "06", "07", "08" -> 8.0;  // Summer (monsoon affects UV)
            case "09", "10", "11" -> 7.0;  // Autumn
            default -> 7.0;
        };

        // Add some random variation (±0.5)
        double variation = Math.random() - 0.5;
        return baseUvIndex + variation;
    }

    public static double predictSunlightHours(String date) {
        String month = date.substring(5, 7);

        // Get predicted UV index
        double predictedUvIndex = predictSolarPotential(date);

        // Predicted cloud cover by month
        double predictedCloudCover = switch(month) {
            case "12", "01", "02" -> 15.0;  // Winter - clearer skies
            case "03", "04", "05" -> 20.0;  // Spring
            case "06", "07", "08" -> 60.0;  // Summer monsoon
            case "09", "10", "11" -> 30.0;  // Autumn
            default -> 25.0;
        };

        return calculateEffectiveSunlightHours(predictedUvIndex, predictedCloudCover);
    }

    public static Map<String, Double> getWeatherPrediction(String date) {
        Map<String, Double> weatherData = new HashMap<>();

        weatherData.put("uvIndex", predictSolarPotential(date));
        weatherData.put("sunlightHours", predictSunlightHours(date));
        weatherData.put("cloudCover", getPredictedCloudCover(date));
        weatherData.put("temperature", getPredictedTemperature(date));

        return weatherData;
    }

    private static double getPredictedCloudCover(String date) {
        String month = date.substring(5, 7);
        return switch(month) {
            case "12", "01", "02" -> 15.0 + (Math.random() * 5);
            case "06", "07", "08" -> 60.0 + (Math.random() * 10);
            default -> 25.0 + (Math.random() * 7);
        };
    }

    private static double getPredictedTemperature(String date) {
        String month = date.substring(5, 7);
        return switch(month) {
            case "12", "01", "02" -> 20.0 + (Math.random() * 5);
            case "03", "04", "05" -> 32.0 + (Math.random() * 5);
            case "06", "07", "08" -> 35.0 + (Math.random() * 3);
            case "09", "10", "11" -> 28.0 + (Math.random() * 5);
            default -> 25.0;
        };
    }

}