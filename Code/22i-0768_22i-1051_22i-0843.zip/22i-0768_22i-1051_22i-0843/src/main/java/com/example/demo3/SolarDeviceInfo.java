package com.example.demo3;

public class SolarDeviceInfo {
    private int numPanels;
    private float systemCapacity;

    // Constructor
    public SolarDeviceInfo(int numPanels, float systemCapacity) {
        this.numPanels = numPanels;
        this.systemCapacity = systemCapacity;
    }

    // Getters
    public int getNumPanels() {
        return numPanels;
    }

    public float getSystemCapacity() {
        return systemCapacity;
    }
}
