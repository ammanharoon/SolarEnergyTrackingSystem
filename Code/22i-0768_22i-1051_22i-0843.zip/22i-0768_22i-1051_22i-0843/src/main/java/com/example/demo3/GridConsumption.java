package com.example.demo3;

import java.time.LocalDate;

public class GridConsumption {
    private String location;
    private LocalDate date;
    private double consumptionKWh;
    private double cost;
    private double peakConsumption;
    private double totalConsumptionKWh;
    private String status;

    // Constructor
    public GridConsumption(String location, LocalDate date, double consumptionKWh, double cost,
                           double peakConsumption, double totalConsumptionKWh, String status) {
        this.location = location;
        this.date = date;
        this.consumptionKWh = consumptionKWh;
        this.cost = cost;
        this.peakConsumption = peakConsumption;
        this.totalConsumptionKWh = totalConsumptionKWh;
        this.status = status;
    }

    // Getters and Setters
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public double getConsumptionKWh() {
        return consumptionKWh;
    }

    public void setConsumptionKWh(double consumptionKWh) {
        this.consumptionKWh = consumptionKWh;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public double getPeakConsumption() {
        return peakConsumption;
    }

    public void setPeakConsumption(double peakConsumption) {
        this.peakConsumption = peakConsumption;
    }

    public double getTotalConsumptionKWh() {
        return totalConsumptionKWh;
    }

    public void setTotalConsumptionKWh(double totalConsumptionKWh) {
        this.totalConsumptionKWh = totalConsumptionKWh;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "GridConsumption{" +
                "location='" + location + '\'' +
                ", date=" + date +
                ", consumptionKWh=" + consumptionKWh +
                ", cost=" + cost +
                ", peakConsumption=" + peakConsumption +
                ", totalConsumptionKWh=" + totalConsumptionKWh +
                ", status='" + status + '\'' +
                '}';
    }
}
