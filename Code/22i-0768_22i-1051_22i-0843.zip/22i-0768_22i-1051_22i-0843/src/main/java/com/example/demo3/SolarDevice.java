package com.example.demo3;

public class SolarDevice {
    private int userId;         // The ID of the user to whom the device belongs
    private float systemCapacity; // Total system capacity in kW
    private int numPanels;      // Number of solar panels
    private String location;    // Location of the solar device

    // Constructor
    public SolarDevice( int userId, float systemCapacity, int numPanels, String location) {

        this.userId = userId;
        this.systemCapacity = systemCapacity;
        this.numPanels = numPanels;
        this.location = location;
    }

    // Getters and Setters




    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public float getSystemCapacity() {
        return systemCapacity;
    }

    public void setSystemCapacity(float systemCapacity) {
        this.systemCapacity = systemCapacity;
    }

    public int getNumPanels() {
        return numPanels;
    }

    public void setNumPanels(int numPanels) {
        this.numPanels = numPanels;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "SolarDevice{" +
                ", userId=" + userId +
                ", systemCapacity=" + systemCapacity +
                ", numPanels=" + numPanels +
                ", location='" + location + '\'' +
                '}';
    }





}
