package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class ViewCO2EmissionsController {

    @FXML
    private Label totalCO2SavedLabel;

    @FXML
    private Label treesEquivalentLabel;

    @FXML
    private Label carMilesEquivalentLabel;

    @FXML
    private BarChart<String, Number> co2BarChart;

    @FXML
    private CategoryAxis xAxis;

    @FXML
    private Button returnButton;


    @FXML
    private NumberAxis yAxis;

    private final double GRID_CO2_FACTOR = 0.4;      // kg CO2 per kWh for grid energy
    private final double SOLAR_CO2_OFFSET_FACTOR = 0.4; // kg CO2 offset per kWh of solar energy

    @FXML
    public void initialize() {
        // Example: Fetching data from databases
        GridConsumptionDatabase gridDatabase = new GridConsumptionDatabase();
        SolarPredictionDatabase solarDatabase = new SolarPredictionDatabase();
        User user = Session.getLoggedInUser(); // Fetch the logged-in user

        List<GridConsumption> gridData = gridDatabase.getGridConsumptionByLocation(user.getCity());
        List<SolarPredictionData> solarData = solarDatabase.getSolarEnergyByLocation(user.getCity());

        // Step 1: Configure Chart Axes
        xAxis.setLabel("Time Period");
        yAxis.setLabel("CO2 Saved (kg)");

        // Step 2: Prepare Data Series for CO2 Saved
        XYChart.Series<String, Number> co2Series = new XYChart.Series<>();
        co2Series.setName("CO2 Saved");

        double totalCO2Saved = 0.0;

        for (int i = 0; i < gridData.size(); i++) {
            GridConsumption gc = gridData.get(i);
            SolarPredictionData sp = solarData.get(i);

            double gridCO2 = gc.getConsumptionKWh() * GRID_CO2_FACTOR;
            double solarCO2Offset = sp.getOutputKWh() * SOLAR_CO2_OFFSET_FACTOR;
            double co2Saved = gridCO2 - solarCO2Offset;

            totalCO2Saved += co2Saved;

            // Add to the chart series
            co2Series.getData().add(new XYChart.Data<>(gc.getDate().toString(), co2Saved));
        }

        // Add the series to the chart
        co2BarChart.getData().add(co2Series);

        // Step 3: Update Labels
        int treesPlantedEquivalent = (int) (totalCO2Saved / 21); // 1 tree absorbs ~21 kg CO2/year
        int carMilesEquivalent = (int) (totalCO2Saved / 0.4);    // 1 mile ~ 0.4 kg CO2

        totalCO2SavedLabel.setText(String.format("Total CO2 Saved: %.2f kg", totalCO2Saved));
        treesEquivalentLabel.setText(String.format("Equivalent to planting %d trees!", treesPlantedEquivalent));
        carMilesEquivalentLabel.setText(String.format("Equivalent to avoiding %d car miles!", carMilesEquivalent));
    }


    @FXML
    private void BacktoDashboard() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("dashboard.fxml"));
        Parent root = null;
        try {
            root = loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stage = (Stage) returnButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

}
