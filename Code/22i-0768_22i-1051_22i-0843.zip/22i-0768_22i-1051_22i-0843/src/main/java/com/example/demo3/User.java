package com.example.demo3;

public class User {
    private final String username;
    private final String password; // Consider storing hashed passwords
    private final String email;
    private final String phone;
    private final String city;
    private final String country;
    private final String status;

    public User(String username, String password, String email, String phone, String city, String country, String status) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.phone = phone;
        this.city = city;
        this.country = country;
        this.status= status;
    }

    // Getters
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getCity() {
        return city;
    }

    public String getCountry() {
        return country;
    }

    public String getStatus() {
        return status;
    }

    // Optionally, override toString for better logging
    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", city='" + city + '\'' +
                ", country='" + country + '\'' +
                '}';
    }


}
