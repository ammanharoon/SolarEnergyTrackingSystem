package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class ProductionConsumptionController implements Initializable {

    @FXML
    private BarChart<String, Number> energyBarChart;

    @FXML
    private CategoryAxis timeAxis;

    @FXML
    private NumberAxis energyAxis;

    @FXML
    private Button refreshButton;

    @FXML
    private Button exportButton;


    @FXML
    private Button backButton2;

    @FXML
    private Label statusLabel;

    private GridConsumptionDatabase gridDatabase = new GridConsumptionDatabase();
    private SolarPredictionDatabase solarDatabase = new SolarPredictionDatabase();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Set up the chart
        initializeChart();

        // Button actions
        refreshButton.setOnAction(event -> refreshData());
        exportButton.setOnAction(event -> exportData());
    }

    private void initializeChart() {
        // Clear the chart
        energyBarChart.getData().clear();

        User user = Session.getLoggedInUser(); // Fetch the logged-in user

        // Fetch grid consumption data
        List<GridConsumption> gridData = gridDatabase.getGridConsumptionByLocation(user.getCity());

        // Fetch solar production data
        List<SolarPredictionData> solarData = solarDatabase.getSolarEnergyByLocation(user.getCity());

        // Create series for grid consumption
        XYChart.Series<String, Number> gridSeries = new XYChart.Series<>();
        gridSeries.setName("Grid Consumption");

        // Populate the grid series
        for (GridConsumption gc : gridData) {
            gridSeries.getData().add(new XYChart.Data<>(gc.getDate().toString(), gc.getConsumptionKWh()));
        }

        // Create series for solar production
        XYChart.Series<String, Number> solarSeries = new XYChart.Series<>();
        solarSeries.setName("Solar Production");

        // Populate the solar series
        for (SolarPredictionData sp : solarData) {
            solarSeries.getData().add(new XYChart.Data<>(sp.getDate().toString(), sp.getOutputKWh()));
        }

        // Add both series to the chart
        energyBarChart.getData().addAll(gridSeries, solarSeries);

        // Update the status label
        statusLabel.setText("Chart updated with grid and solar data.");
    }

    private void refreshData() {
        // Refresh both grid and solar data
        statusLabel.setText("Refreshing data...");
        initializeChart(); // Reinitialize the chart with fresh data
        statusLabel.setText("Data refreshed successfully.");
    }

    private void exportData() {
        // Placeholder for export functionality
        System.out.println("Exporting data...");
        statusLabel.setText("Data export functionality is not implemented yet.");
    }


    @FXML
    private void gobacktoSolarDashboard() {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("solargeneration.fxml"));
        Parent root = null;
        try {
            root = loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stage = (Stage) backButton2.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

}
