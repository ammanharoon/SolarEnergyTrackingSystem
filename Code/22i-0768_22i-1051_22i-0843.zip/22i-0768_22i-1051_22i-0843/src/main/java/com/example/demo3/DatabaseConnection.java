
// DatabaseConnection.java
package com.example.demo3;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {
    private Connection databaseLink;
 //   private static DatabaseConnection instance;

    public Connection getConnection() {
        String databaseName = "solar";
        String databaseUser = "root";
        String databasePassword = "123456";
        String url = "jdbc:mysql://localhost:3306/" + databaseName;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            databaseLink = DriverManager.getConnection(url, databaseUser, databasePassword);
            System.out.println("Database connection successful!");
        } catch (Exception e) {
            System.out.println("Error connecting to database: " + e.getMessage());
            e.printStackTrace();
        }

        return databaseLink;
    }
}
