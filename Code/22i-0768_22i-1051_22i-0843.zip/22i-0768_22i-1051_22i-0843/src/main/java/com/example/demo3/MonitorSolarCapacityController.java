package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class MonitorSolarCapacityController {

    @FXML
    private Label solarProductionLabel;

    @FXML
    private Label solarEfficiencyLabel;

    @FXML
    private Label totalEnergyProducedLabel;

    @FXML
    private Button returnButton;

    @FXML
    private PieChart solarStatusPieChart;

    // Method to initialize the data for the PieChart
    public void initialize() {
        User user= Session.getLoggedInUser();
        System.out.println(user.getCity());
        SolarEnergy solarEnergy = new SolarEnergy(1,4.5f, 15, user.getCity());
        // Calculate and display energy output
        solarEnergy.CalculateEnergy(user.getCity());
        // Example data to update labels
        // Assuming solarEnergy is an object that has methods getEnergyOutput(), getYieldEfficiency(), and getYieldPerKW()

        solarProductionLabel.setText(String.format("Solar Production (kWh): %.2f", solarEnergy.getEnergyOutput()));
        solarEfficiencyLabel.setText(String.format("Yield Per KWH: %.2f%%", solarEnergy.getYieldEfficency()));
        totalEnergyProducedLabel.setText(String.format("Total Yield Efficiency: %.2f%%", solarEnergy.getYieldPerKW()));


        // Create PieChart.Data objects for the chart
        PieChart.Data operationalData = new PieChart.Data("Operational", 100);
        PieChart.Data nonOperationalData = new PieChart.Data("Non-Operational", 0);

        // Clear any existing data and add the new data
        solarStatusPieChart.getData().clear();
        solarStatusPieChart.getData().addAll(operationalData, nonOperationalData);
    }


    @FXML
    private void BacktoDashboard() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("dashboard.fxml"));
        Parent root = null;
        try {
            root = loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stage = (Stage) returnButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

}
