package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class ChangeUsernameController {

    @FXML
    private TextField oldUsernameField;

    @FXML
    private TextField newUsernameField;

    @FXML
    private Label errorMessageLabel;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    // This method is triggered when the "Save Changes" button is clicked
    @FXML
    private void handleSaveChanges() {
        String oldUsername = oldUsernameField.getText().trim();
        String newUsername = newUsernameField.getText().trim();

        // Validate the input
        if (oldUsername.isEmpty() || newUsername.isEmpty()) {
            errorMessageLabel.setText("Both fields are required!");
            return;
        }


        User curruser= Session.getLoggedInUser();


        if (curruser.getUsername().equals(newUsername)) { // Replace with actual logic to validate old username
            errorMessageLabel.setText("Old username does is same as old.");
            return;
        }

        System.out.println(curruser.getUsername());
        UserRepository user= new UserRepository();
        user.updateUsername(curruser.getUsername(), newUsername);



        System.out.println("Username changed successfully to: " + newUsername);

        // Close the window after saving

    }

    // This method is triggered when the "Cancel" button is clicked
    @FXML
    private void handleCancel() {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("manageuserprofile.fxml"));
        Parent root = null;
        try {
            root = loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    // Helper method to close the window

}
