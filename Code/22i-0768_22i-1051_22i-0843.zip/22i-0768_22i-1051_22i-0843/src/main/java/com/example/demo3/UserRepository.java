package com.example.demo3;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserRepository {

    public User findByUsername(String username) throws SQLException {


        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        if (connectDB == null) {
            showError("Database connection failed. Please try again later.");

        }
        String query = "SELECT * FROM users WHERE username = ?";
        assert connectDB != null;
        try (PreparedStatement preparedStatement = connectDB.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            ResultSet result = preparedStatement.executeQuery();
            if (result.next()) {
                return new User(
                        result.getString("username"),
                        result.getString("password"),
                        result.getString("email"),
                        result.getString("phone"),
                        result.getString("city"),
                        result.getString("country"),
                        result.getString("status")
                );
            }

        }
        catch (SQLException e) {
            System.err.println("Error finding user by username: " + e.getMessage());
            e.printStackTrace();
        }

        return null;
    }


    public boolean save(User user) {

        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        if (connectDB == null) {
            showError("Database connection failed. Please try again later.");
            return false;
        }



        String query = "INSERT INTO users (username, password, email, phone, city, country) VALUES (?, ?, ?, ?, ?, ?)";



        try (PreparedStatement preparedStatement = connectDB.prepareStatement(query)) {
            preparedStatement.setString(1, user.getUsername());
            preparedStatement.setString(2, user.getPassword()); // In production, hash the password!
            preparedStatement.setString(3, user.getEmail());
            preparedStatement.setString(4, user.getPhone());
            preparedStatement.setString(5, user.getCity());
            preparedStatement.setString(6, user.getCountry());

            int result = preparedStatement.executeUpdate();

            if (result > 0) {
                showSuccess("Registration successful!");
                // Optional: Automatically return to login page after successful registration
                return true;
            } else {
                showError("Registration failed. Please try again.");
                return false;
            }
        }


        catch (SQLException e) {
            if (e.getErrorCode() == 1062) { // Duplicate entry
                System.err.println("Duplicate entry: " + e.getMessage());
            } else {
                System.err.println("Error saving user: " + e.getMessage());
            }
            e.printStackTrace();
        }
        return false;
    }

    private void showSuccess(String s) {
    }

    private void showError(String s) {
    }


    public boolean updatePassword(String username, String newPassword) {
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        if (connectDB == null) {
            showError("Database connection failed. Please try again later.");
            return false;
        }

        String query = "UPDATE users SET password = ? WHERE username = ?";

        try (PreparedStatement preparedStatement = connectDB.prepareStatement(query)) {
            preparedStatement.setString(1, newPassword); // In production, hash the password!
            preparedStatement.setString(2, username);

            int rowsUpdated = preparedStatement.executeUpdate();

            if (rowsUpdated > 0) {
                showSuccess("Password updated successfully!");
                return true;
            } else {
                showError("User not found or password not updated.");
                return false;
            }
        } catch (SQLException e) {
            System.err.println("Error updating password: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }


    public boolean updateUsername(String currentUsername, String newUsername) {
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        if (connectDB == null) {
            showError("Database connection failed. Please try again later.");
            return false;
        }

        String query = "UPDATE users SET username = ? WHERE username = ?";

        try (PreparedStatement preparedStatement = connectDB.prepareStatement(query)) {
            preparedStatement.setString(1, newUsername);
            preparedStatement.setString(2, currentUsername);

            int rowsUpdated = preparedStatement.executeUpdate();

            if (rowsUpdated > 0) {
                showSuccess("Username updated successfully!");
                return true;
            } else {
                showError("User not found or username not updated.");
                return false;
            }
        } catch (SQLException e) {
            System.err.println("Error updating username: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }




}
