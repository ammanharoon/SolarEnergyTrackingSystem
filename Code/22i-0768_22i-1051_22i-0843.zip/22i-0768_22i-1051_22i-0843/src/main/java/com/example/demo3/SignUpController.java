package com.example.demo3;







import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import java.io.IOException;

public class SignUpController {

    // Input Fields
    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField phoneField;

    @FXML
    private TextField cityField;

    @FXML
    private TextField countryField;

    // Buttons
    @FXML
    private Button registerButton;

    @FXML
    private Button backButton;

    // Message Labels
    @FXML
    private Label messageLabel; // Ensure this matches the fx:id in FXML

    // Services
    private final AuthenticationService authenticationService = new AuthenticationService();

    /**
     * Handles the sign-up action.
     *
     * @param event The action event.
     */


    @FXML
    private void handleSignUp(ActionEvent event) {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String city = cityField.getText().trim();
        String country = countryField.getText().trim();
        String status= "unregistered";

        // Create User object
        User user = new User(username, password, email, phone, city, country, status);
        UserRepository newuser = new UserRepository();

        // Attempt registration
        boolean isRegistered = authenticationService.register(user);
        newuser.save(user);

        if (isRegistered) {
            messageLabel.setText("Registration successful!");
            messageLabel.setStyle("-fx-text-fill: green;");
            backToLoginAction(); // Optionally navigate back to login
        } else {
            messageLabel.setText("Registration failed. Please check your inputs.");
            messageLabel.setStyle("-fx-text-fill: red;");
        }
    }

    /**
     * Navigates back to the login screen.
     */



    @FXML
    private void backToLoginAction() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            messageLabel.setText("Error returning to login: " + e.getMessage());
            messageLabel.setStyle("-fx-text-fill: red;");
            e.printStackTrace();
        } catch (Exception e) {
            messageLabel.setText("Unexpected error: " + e.getMessage());
            messageLabel.setStyle("-fx-text-fill: red;");
            e.printStackTrace();
        }
    }
}
