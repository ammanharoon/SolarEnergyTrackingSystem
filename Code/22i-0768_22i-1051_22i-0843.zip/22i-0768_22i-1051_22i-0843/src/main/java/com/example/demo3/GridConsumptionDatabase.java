package com.example.demo3;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GridConsumptionDatabase {

    public List<GridConsumption> getGridConsumptionByLocation(String location) {
        List<GridConsumption> gridData = new ArrayList<>();

        String query = "SELECT location, date, consumption_kWh, cost, peakConsumption, totalConsumption_kWh, status " +
                "FROM grid_consumption WHERE location = ? limit 10 ";

        DatabaseConnection conne = new DatabaseConnection(); // Replace with your actual connection class
        Connection connectDB = conne.getConnection();

        if (connectDB == null) {
            System.err.println("Database connection failed.");
            return gridData;
        }

        try (PreparedStatement pstmt = connectDB.prepareStatement(query)) {
            pstmt.setString(1, location);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                GridConsumption gridConsumption = new GridConsumption(
                        rs.getString("location"),
                        rs.getDate("date").toLocalDate(),
                        rs.getDouble("consumption_kWh"),
                        rs.getDouble("cost"),
                        rs.getDouble("peakConsumption"),
                        rs.getDouble("totalConsumption_kWh"),
                        rs.getString("status")
                );
                gridData.add(gridConsumption);
            }
        } catch (SQLException e) {
            System.err.println("Query error: " + e.getMessage());
        }

        return gridData;
    }
}
