
package com.example.demo3;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField PasswordField;

    @FXML
    private Button loginbutton;

    @FXML
    private Button signupbutton;

    @FXML
    private Label loginMessageLabel;

    private final AuthenticationService authenticationService = new AuthenticationService();

    @FXML
    private void handleLogin(ActionEvent event) throws IOException, SQLException {
        String username = usernameField.getText();
        String password = PasswordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            loginMessageLabel.setText("Please enter both username and password.");
            return;
        }


        boolean isAuthenticated = authenticationService.authenticate(username, password);

        if (isAuthenticated) {
            loginMessageLabel.setText("Login successful!");
            final UserRepository userRepository = new UserRepository();
            User loggedInUser = userRepository.findByUsername(username);
            Session.setLoggedInUser(loggedInUser);

            if (authenticationService.getstatus(username, password)) {

                // Navigate to next screen (e.g., dashboard.fxml)
                FXMLLoader loader = new FXMLLoader(getClass().getResource("dashboard.fxml"));
                Parent root = loader.load();

                Stage stage = (Stage) loginbutton.getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();
            } else {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("solardevice.fxml"));
                Parent root = loader.load();

                Stage stage = (Stage) loginbutton.getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();


            }
        }
         else {
            loginMessageLabel.setText("Invalid username or password.");
        }
    }

    @FXML
    private void handleSignup(ActionEvent event) {
        // Navigate to signup screen
        try {
            // Load the signup FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("signup.fxml"));
            Parent root;
            root = loader.load();

            // Create new stage
            Stage signupStage = new Stage();
            signupStage.setTitle("Sign Up");
            signupStage.setScene(new Scene(root));

            // Close current stage
            Stage currentStage = (Stage) signupbutton.getScene().getWindow();
            currentStage.close();

            // Show new stage
            signupStage.show();

        } catch (IOException e) {
            loginMessageLabel.setText("Error loading signup page: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            loginMessageLabel.setText("Unexpected error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

