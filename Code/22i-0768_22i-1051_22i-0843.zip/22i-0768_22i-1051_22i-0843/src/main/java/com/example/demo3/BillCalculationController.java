package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class BillCalculationController {

    @FXML
    private Label solarEnergyLabel;

    @FXML
    private Label gridEnergyLabel;

    @FXML
    private Label netEnergyLabel;

    @FXML
    private Label excessEnergyPaymentLabel;

    @FXML
    private Label gridEnergyCostLabel;

    @FXML
    private Label totalBillLabel;

    @FXML
    private Label statusLabel;

    @FXML
    private Button calculateButton;

    @FXML
    private Button backButton;

    private GridConsumptionDatabase gridDatabase = new GridConsumptionDatabase();
    private SolarPredictionDatabase solarDatabase = new SolarPredictionDatabase();

    private final double SOLAR_EXPORT_RATE = 10.0; // Price per kWh for excess solar energy
    private final double GRID_CONSUMPTION_RATE = 15.0; // Price per kWh for grid consumption

    @FXML
    public void handleCalculateBill() {
        try {
            User user = Session.getLoggedInUser(); // Fetch logged-in user
            String city = user.getCity();

            // Fetch grid consumption data
            List<GridConsumption> gridData = gridDatabase.getGridConsumptionByLocation(city);

            // Fetch solar production data
            List<SolarPredictionData> solarData = solarDatabase.getSolarEnergyByLocation(city);

            // Calculate total solar energy produced
            double totalSolarEnergy = 0.0;
            for (SolarPredictionData sp : solarData) {
                totalSolarEnergy += sp.getOutputKWh();
            }

            // Calculate total grid energy consumed
            double totalGridEnergy = 0.0;
            for (GridConsumption gc : gridData) {
                totalGridEnergy += gc.getConsumptionKWh();
            }

            // Calculate net energy
            double netEnergy = totalGridEnergy - totalSolarEnergy;

            // Calculate excess energy payment
            double excessEnergyPayment = SOLAR_EXPORT_RATE * Math.max(0, -netEnergy);

            // Calculate grid energy cost
            double gridEnergyCost = GRID_CONSUMPTION_RATE * Math.max(0, netEnergy);

            // Calculate total bill
            double totalBill = gridEnergyCost - excessEnergyPayment;

            // Update UI labels
            solarEnergyLabel.setText(String.format("%.2f kWh", totalSolarEnergy));
            gridEnergyLabel.setText(String.format("%.2f kWh", totalGridEnergy));
            netEnergyLabel.setText(String.format("%.2f kWh", netEnergy));
            excessEnergyPaymentLabel.setText(String.format("PKR %.2f", excessEnergyPayment));
            gridEnergyCostLabel.setText(String.format("PKR %.2f", gridEnergyCost));
            totalBillLabel.setText(String.format("PKR %.2f", totalBill));
            statusLabel.setText("Bill calculated successfully!");
        } catch (Exception e) {
            statusLabel.setText("Error calculating bill: " + e.getMessage());
        }
    }

    @FXML
    public void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("dashboard.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            statusLabel.setText("Error navigating back: " + e.getMessage());
        }
    }
}
