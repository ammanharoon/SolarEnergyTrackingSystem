package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.Node;
import javafx.event.ActionEvent;
import java.io.IOException;

public class DashboardController {

    private void navigateToPage(String fxmlFile, ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // You might want to show an error dialog here
            System.out.println("Error loading " + fxmlFile + ": " + e.getMessage());
        }
    }

    @FXML
    private void goToViewConsumption(ActionEvent event) {
        navigateToPage("gridconsumption.fxml", event);
    }

    @FXML
    private void goToSolarGeneration(ActionEvent event) {
        navigateToPage("solargeneration.fxml", event);
    }

    @FXML
    private void goToGenerateBill(ActionEvent event) {
        navigateToPage("billcalculation.fxml", event);
    }

    @FXML
    private void goToBillHistory(ActionEvent event) {
        navigateToPage("bill-history.fxml", event);
    }

    @FXML
    private void goToManageProfile(ActionEvent event) {
        navigateToPage("manageuserprofile.fxml", event);
    }

    @FXML
    private void goToAboutPage(ActionEvent event) {
        navigateToPage("about.fxml", event);
    }


    @FXML
    private void goToViewCO2Emissions(ActionEvent event) {
        navigateToPage("viewco2emissions.fxml", event);
    }

    @FXML
    private void goToEnergyPrediction(ActionEvent event) {
        navigateToPage("solarprediction.fxml", event);
    }


    @FXML
    private void goToDeleteSolarDevice(ActionEvent event) {
        navigateToPage("deletesolardevice.fxml", event);
    }


    @FXML
    public void loadDashboardScreen(ActionEvent event) {
        try {
            // Load the Dashboard FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("dashboard.fxml"));
            Parent dashboardRoot = loader.load();

            // Set the scene to the stage
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(dashboardRoot);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // You can add error handling logic here
        }
    }









    // Optional: Add an initialize method if you need to set up anything when the dashboard loads
    @FXML
    public void initialize() {
        // Any initialization code goes here
        System.out.println("Dashboard initialized");
    }
}