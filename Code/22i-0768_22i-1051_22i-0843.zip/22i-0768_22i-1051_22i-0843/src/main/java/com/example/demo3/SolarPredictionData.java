package com.example.demo3;

import java.time.LocalDate;

public class SolarPredictionData {
    private String location;
    private LocalDate date;
    private double outputKWh;
    private double yield;
    private double yieldEfficiency;
    private double totalCapacity;
    private String status;

    public SolarPredictionData(String location, LocalDate date, double outputKWh, double yield, double yieldEfficiency, double totalCapacity, String status) {
        this.location = location;
        this.date = date;
        this.outputKWh = outputKWh;
        this.yield = yield;
        this.yieldEfficiency = yieldEfficiency;
        this.totalCapacity = totalCapacity;
        this.status = status;
    }

    // Getters and Setters
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public double getOutputKWh() {
        return outputKWh;
    }

    public void setOutputKWh(double outputKWh) {
        this.outputKWh = outputKWh;
    }

    public double getYield() {
        return yield;
    }

    public void setYield(double yield) {
        this.yield = yield;
    }

    public double getYieldEfficiency() {
        return yieldEfficiency;
    }

    public void setYieldEfficiency(double yieldEfficiency) {
        this.yieldEfficiency = yieldEfficiency;
    }

    public double getTotalCapacity() {
        return totalCapacity;
    }

    public void setTotalCapacity(double totalCapacity) {
        this.totalCapacity = totalCapacity;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "SolarEnergyData{" +
                "location='" + location + '\'' +
                ", date=" + date +
                ", outputKWh=" + outputKWh +
                ", yield=" + yield +
                ", yieldEfficiency=" + yieldEfficiency +
                ", totalCapacity=" + totalCapacity +
                ", status='" + status + '\'' +
                '}';
    }
}
