package com.example.demo3;

import java.sql.SQLException;

import java.sql.SQLException;

public class AuthenticationService {

    private final UserRepository userRepository = new UserRepository();
    private final InputValidator inputValidator = new InputValidator();

    public boolean authenticate(String username, String password) throws SQLException {
        User user = userRepository.findByUsername(username);
        return user != null && user.getPassword().equals(password);
    }



    public boolean getstatus(String username, String passowrd) throws SQLException {
        User user = userRepository.findByUsername(username);
        if ("unregistered".equals(user.getStatus())) {
            return false;
        }
        return true;
    }

    public boolean register(User user) {
        if (user.getUsername() == null || user.getUsername().isEmpty()) {
            System.out.println("Failed: Username is empty");
            return false;
        }
        if (user.getPassword() == null || user.getPassword().isEmpty()) {
            System.out.println("Failed: Password is empty");
            return false;
        }
        if (user.getEmail() == null || user.getEmail().isEmpty()) {
            System.out.println("Failed: Email is empty");
            return false;
        }

        System.out.println("User data looks good: " + user);
        return true; // Simulate successful registration
    }

}
