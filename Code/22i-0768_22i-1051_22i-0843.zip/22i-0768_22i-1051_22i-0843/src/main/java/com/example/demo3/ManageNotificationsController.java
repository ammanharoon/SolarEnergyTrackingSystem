package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class ManageNotificationsController {

    // Shared Notifications object (static to persist across visits)
    private static Notifications notifications = new Notifications(true, true, true);

    // FXML fields for UI elements
    @FXML
    private CheckBox emailNotification;

    @FXML
    private CheckBox smsNotification;

    @FXML
    private CheckBox appNotification;

    @FXML
    private Button saveButton;

    @FXML
    private Button saveButton1;

    // This method is triggered when the "Save Preferences" button is clicked
    @FXML
    private void handleSavePreferences() {
        // Update the Notifications object with current checkbox states
        notifications.setEmailNotification(emailNotification.isSelected());
        notifications.setSmsNotification(smsNotification.isSelected());
        notifications.setAppNotification(appNotification.isSelected());

        // Print the preferences to the console for debugging
        System.out.println("Preferences saved: " + notifications);
    }

    @FXML
    private void returntoDashboard() {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("manageuserprofile.fxml"));
        Parent root = null;
        try {
            root = loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stage = (Stage) saveButton1.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    // This method initializes the page with current preferences
    public void initialize() {
        // Use the static Notifications object to retain preferences
        emailNotification.setSelected(notifications.isEmailNotification());
        smsNotification.setSelected(notifications.isSmsNotification());
        appNotification.setSelected(notifications.isAppNotification());
    }
}
