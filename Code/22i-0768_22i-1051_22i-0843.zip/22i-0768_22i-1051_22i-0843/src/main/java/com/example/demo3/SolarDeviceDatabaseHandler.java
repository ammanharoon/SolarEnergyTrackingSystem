package com.example.demo3;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SolarDeviceDatabaseHandler {
    public static void insertDevice(SolarDevice device) {
        String query = "INSERT INTO solardevice (userId, systemCapacity, numPanels, location) VALUES ( ?, ?, ?, ?)";

        DatabaseConnection conn = new DatabaseConnection();
        Connection connectDB = conn.getConnection();
        try( PreparedStatement stmt = connectDB.prepareStatement(query)) {

            stmt.setInt(1, device.getUserId());
            stmt.setFloat(2, device.getSystemCapacity());
            stmt.setInt(3, device.getNumPanels());
            stmt.setString(4, device.getLocation());

            stmt.executeUpdate();
            System.out.println("Solar device successfully inserted!");
        } catch (SQLException e) {
            e.printStackTrace();
        }


        String updatequery = "Update users set status= 'registered' where id = ? ";
            DatabaseConnection cone = new DatabaseConnection();
            Connection connectinDb= cone.getConnection();
            try(PreparedStatement updateStmt = connectinDb.prepareStatement(updatequery))  {

                updateStmt.setInt(1, device.getUserId());
                int rss = updateStmt.executeUpdate();


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public static void deleteDevice(String username) {
        DatabaseConnection conn = new DatabaseConnection();
        Connection connectDB = conn.getConnection();

        // Query to get the userId based on username
        String getUserIdQuery = "SELECT id FROM users WHERE username = ?";
        String deleteDeviceQuery = "DELETE FROM solardevice WHERE userId = ?";
        String unregisterUserQuery = "UPDATE users SET status = 'unregistered' WHERE id = ?";

        try (PreparedStatement userIdStmt = connectDB.prepareStatement(getUserIdQuery)) {
            userIdStmt.setString(1, username);
            ResultSet result = userIdStmt.executeQuery();

            if (result.next()) {
                int userId = result.getInt("id");

                // Delete the device associated with the userId
                try (PreparedStatement deleteStmt = connectDB.prepareStatement(deleteDeviceQuery)) {
                    deleteStmt.setInt(1, userId);
                    int rowsAffected = deleteStmt.executeUpdate();
                    if (rowsAffected > 0) {
                        System.out.println("Solar device deleted successfully for user: " + username);
                    } else {
                        System.out.println("No solar device found for user: " + username);
                    }
                }

                // Update the user status to unregistered
                try (PreparedStatement unregisterStmt = connectDB.prepareStatement(unregisterUserQuery)) {
                    unregisterStmt.setInt(1, userId);
                    unregisterStmt.executeUpdate();
                    System.out.println("User status set to 'unregistered' for user: " + username);
                }

            } else {
                System.out.println("User not found: " + username);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error occurred while deleting device for user: " + username, e);
        }
    }


    public static SolarDeviceInfo getSolarDeviceInfoByUsername(String username) {
        String query = "SELECT s.numPanels, s.systemCapacity " +
                "FROM solardevice s " +
                "JOIN users u ON u.id = s.userId " +
                "WHERE u.username = ?";

        DatabaseConnection conn = new DatabaseConnection();
        Connection connectDB = conn.getConnection();

        // Declare variables for numPanels and systemCapacity
        int numPanels = 0;
        float systemCapacity = 0;

        try (PreparedStatement stmt = connectDB.prepareStatement(query)) {
            stmt.setString(1, username); // Set username as parameter
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                // Get values from the result set
                numPanels = resultSet.getInt("numPanels");
                systemCapacity = resultSet.getFloat("systemCapacity");
            } else {
                System.out.println("No data found for username: " + username);
                return null; // If no data found, return null
            }

        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
            return null; // Return null in case of an error
        }

        // Return a new SolarDeviceInfo object with the retrieved values
        return new SolarDeviceInfo(numPanels, systemCapacity);
    }
}

