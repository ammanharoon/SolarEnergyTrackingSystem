package com.example.demo3;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SolarPredictionDatabase {

    public List<SolarPredictionData> getSolarEnergyByLocation(String location) {
        List<SolarPredictionData> solarEnergyDataList = new ArrayList<>(); // Updated the type to SolarPredictionData

        String query = "SELECT location, date, output_kWh, yield, yield_efficiency, totalCapacity, status " +
                "FROM solar_energy_data WHERE location = ? LIMIT 10";

        DatabaseConnection conne = new DatabaseConnection(); // Replace with your actual connection class
        Connection connectDB = conne.getConnection();

        if (connectDB == null) {
            System.err.println("Database connection failed.");
            return solarEnergyDataList;
        }

        try (PreparedStatement pstmt = connectDB.prepareStatement(query)) {
            pstmt.setString(1, location);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                SolarPredictionData solarPredictionData = new SolarPredictionData(
                        rs.getString("location"),
                        rs.getDate("date").toLocalDate(),
                        rs.getDouble("output_kWh"),
                        rs.getDouble("yield"),
                        rs.getDouble("yield_efficiency"),
                        rs.getDouble("totalCapacity"),
                        rs.getString("status")
                );

                solarEnergyDataList.add(solarPredictionData); // No error now
            }
        } catch (SQLException e) {
            System.err.println("Query error: " + e.getMessage());
        }

        return solarEnergyDataList;
    }
}
