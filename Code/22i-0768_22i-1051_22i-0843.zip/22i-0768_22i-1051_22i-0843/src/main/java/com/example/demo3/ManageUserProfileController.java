package com.example.demo3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class ManageUserProfileController {

    @FXML
    private Button setNotificationPreferencesButton;

    @FXML
    private Button monitorSolarCapacityButton;

    @FXML
    private Button changePasswordButton;

    @FXML
    private Button changeUsernameButton;

    @FXML
    private Button returnButton;

    @FXML
    private ImageView notificationIcon;

    @FXML
    private ImageView monitorSolarIcon;

    @FXML
    private ImageView changePasswordIcon;

    @FXML
    private ImageView changeUsernameIcon;



    private void navigateToPage(String fxmlFile, ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // You might want to show an error dialog here
            System.out.println("Error loading " + fxmlFile + ": " + e.getMessage());
        }
    }

    @FXML
    private void handleSetNotificationPreferences(ActionEvent event) {

        navigateToPage("manageusernotification.fxml", event);

    }


    @FXML
    private void handleMonitorSolarCapacity(ActionEvent event) {
        System.out.println("Navigating to Solar Capacity Monitoring...");
        navigateToPage("monitorsolarcapacity.fxml", event);

    }


    @FXML
    private void handleChangePassword(ActionEvent event) {
        System.out.println("Navigating to Change Password...");
        navigateToPage("changepassword.fxml", event);
        // Add your navigation or logic here
    }

    // Action for 'Change Username'
    @FXML
    private void handleChangeUsername(ActionEvent event) {
        System.out.println("Navigating to Change Username...");
        navigateToPage("changeusername.fxml", event);
        // Add your navigation or logic here
    }



    @FXML
    private void BacktoDashboard() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("dashboard.fxml"));
        Parent root = null;
        try {
            root = loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stage = (Stage) returnButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }



}
