package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class DeleteSolarDeviceController {


    @FXML
    private Button backButton;

    @FXML
    private Label systemCapacityLabel;

    @FXML
    private Label numPanelsLabel;

    @FXML
    private Label locationLabel;

    @FXML
    private Label statusLabel;

    @FXML
    private Button deleteButton;

    private SolarDeviceDatabaseHandler databaseHandler = new SolarDeviceDatabaseHandler();

    /**
     * This method is automatically called by JavaFX after the FXML is loaded
     */
    @FXML
    private void initialize() {
        loadSolarDeviceDetails();
    }

    /**
     * Loads the current solar device details from the database and displays them.
     */
    private void loadSolarDeviceDetails() {
        try {
            User userr = Session.getLoggedInUser();
            if (userr == null) {
                statusLabel.setText("No user logged in.");
                deleteButton.setDisable(true);
                return;
            }

            SolarDeviceInfo deviceInfo = SolarDeviceDatabaseHandler.getSolarDeviceInfoByUsername(userr.getUsername());

            if (userr.getStatus().equals("registered") && deviceInfo != null) {
                systemCapacityLabel.setText(String.format("%.2f", deviceInfo.getSystemCapacity()));
                numPanelsLabel.setText(String.valueOf(deviceInfo.getNumPanels()));
                locationLabel.setText(userr.getCity());
                statusLabel.setText(""); // Clear any previous error messages
            } else {
                statusLabel.setText("No solar device found for the user.");
                deleteButton.setDisable(true); // Disable delete button if no device is found
            }
        } catch (Exception e) {
            statusLabel.setText("Error loading device details. Please try again.");
            e.printStackTrace();
        }
    }

    /**
     * Handles the deletion of the solar device when the "Delete" button is clicked.
     */
    @FXML
    private void handleDeleteDevice() {
        try {
            User userr = Session.getLoggedInUser();
            if (userr == null) {
                statusLabel.setText("No user logged in.");
                return;
            }

            SolarDeviceDatabaseHandler.deleteDevice(userr.getUsername());
            statusLabel.setText("Solar device deleted successfully.");
            deleteButton.setDisable(true); // Prevent multiple deletions

            // Clear the labels after deletion
            systemCapacityLabel.setText("");
            numPanelsLabel.setText("");
            locationLabel.setText("");
        } catch (Exception e) {
            statusLabel.setText("Error deleting solar device. Please try again.");
            e.printStackTrace();
        }
    }


    @FXML
    private void BacktoDashboard() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("dashboard.fxml"));
        Parent root = null;
        try {
            root = loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }


}