package com.example.demo3;

import java.sql.*;
import java.util.Map;

import java.time.LocalDate;

public class SolarEnergy extends SolarDevice {
private double energyOutput;
private double yieldPerKW;
private double yieldEfficiency;
private double UV;
private double cloudCover;


    public SolarEnergy(int userId, float systemCapacity, int numPanels, String location) {
        super(userId, systemCapacity, numPanels, location);
    }

    // Method to calculate solar energy output based on data from the database
    public void CalculateEnergy(String locationn) {
        float systemcapacity=0;
        int numofpanels=0;
        // Retrieve sunlight hours for the user's location from the database
        double sunlightHours = getSunlightHoursFromDatabase(locationn);
        if (sunlightHours == 0) {
            System.out.println("No sunlight data available for " + getLocation());
            return;
        }
       double efficiency= 0.8;
        double uvi= getUVFromDatabase(locationn);
        setUV(uvi);
        String query = "SELECT s.numPanels, s.systemCapacity " +
                "FROM solardevice s " +
                "JOIN users u ON u.id = s.userId " +
                "WHERE u.username = ?";


        DatabaseConnection conn = new DatabaseConnection();
        Connection connectDB = conn.getConnection();

        try (PreparedStatement stmt = connectDB.prepareStatement(query)) {
            // Assuming you have the username
            User user= Session.getLoggedInUser();
            String username = user.getUsername();

            // Set the username parameter in the query
            stmt.setString(1, username);

            // Execute the query
            ResultSet resultSet = stmt.executeQuery();

            // Process the result
            if (resultSet.next()) {
                 numofpanels = resultSet.getInt("numPanels");
                 setNumPanels(numofpanels);
                 systemcapacity = resultSet.getFloat("systemCapacity");
                 setSystemCapacity(systemcapacity);

                System.out.println("Number of Panels: " + numofpanels);
                System.out.println("System Capacity: " + systemcapacity + " kW");
            } else {
                System.out.println("No data found for username: " + username);
            }

        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        }

        double solarEfficiency= 0.8;

        // Calculate energy output (in kWh) based on sunlight hours and panel efficiency
        // Assuming each panel produces 1 kW per sunlight hour
        energyOutput = sunlightHours * (systemcapacity) * 0.86;
        double theoreticalMax = systemcapacity * sunlightHours; // Max possible energy
        yieldEfficiency = (energyOutput / theoreticalMax) * 100; // In percentage
        yieldPerKW = energyOutput / systemcapacity; // In kWh/kW


        // Display Results

    }

    // Method to retrieve sunlight hours from the database for the given location
    private double getSunlightHoursFromDatabase(String location) {
        double sunlightHours = 0.0;

        // Establish DB connection
        SolarEnergyDatabase solarDatabase = new SolarEnergyDatabase();
        Map<String, Double> weatherData = solarDatabase.getCurrentWeatherData(location);

        // If data exists, get the sunlight hours
        if (weatherData != null && weatherData.containsKey("sunlightHours")) {
            sunlightHours = weatherData.get("sunlightHours");
        }

        return sunlightHours;
    }

    private double getUVFromDatabase(String location) {
        double UVindex = 0.5;

        // Establish DB connection
        SolarEnergyDatabase solarDatabase = new SolarEnergyDatabase();
        Map<String, Double> weatherData = solarDatabase.getCurrentWeatherData(location);

        // If data exists, get the sunlight hours
        if (weatherData != null && weatherData.containsKey("uv_index")) {
            UVindex = weatherData.get("uv_index");
            setUV(UVindex);
            System.out.println(UVindex);

        }

        return UVindex;
    }




    public void calculateEnergyForDates(String location) {
        float systemCapacity = 0;
        int numOfPanels = 0;

        // Retrieve sunlight hours for the user's location from the database
        double sunlightHours = getSunlightHoursFromDatabase(location);
        if (sunlightHours == 0) {
            System.out.println("No sunlight data available for " + location);
            return;
        }

        // Retrieve system capacity and number of panels for the user
        String query = "SELECT s.numPanels, s.systemCapacity " +
                "FROM solardevice s " +
                "JOIN users u ON u.id = s.userId " +
                "WHERE u.username = ?";

        DatabaseConnection conn = new DatabaseConnection();
        Connection connectDB = conn.getConnection();

        try (PreparedStatement stmt = connectDB.prepareStatement(query)) {
            User user = Session.getLoggedInUser(); // Assuming user is logged in
            String username = user.getUsername();

            stmt.setString(1, username);
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                numOfPanels = resultSet.getInt("numPanels");
                setNumPanels(numOfPanels);
                systemCapacity = resultSet.getFloat("systemCapacity");
                setSystemCapacity(systemCapacity);

                System.out.println("Number of Panels: " + numOfPanels);
                System.out.println("System Capacity: " + systemCapacity + " kW");
            } else {
                System.out.println("No data found for username: " + username);
                return; // Exit if no data is found
            }

        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
            return; // Exit on database error
        }

        // Calculate solar energy metrics
        double efficiency = 0.8; // Efficiency factor
        double uvi = getUVFromDatabase(location); // Retrieve UV index
        setUV(uvi);

        energyOutput = sunlightHours * systemCapacity * 0.86; // Output in kWh
        double theoreticalMax = systemCapacity * sunlightHours; // Max possible energy
        yieldEfficiency = (energyOutput / theoreticalMax) * 100; // Efficiency in percentage
        yieldPerKW = energyOutput / systemCapacity; // Yield per kW

        System.out.println("Solar Energy Output: " + energyOutput + " kWh");
        System.out.println("Yield Efficiency: " + yieldEfficiency + " %");
        System.out.println("Yield Per kW: " + yieldPerKW + " kWh/kW");

        // Insert data for 10 dates
        LocalDate startDate = LocalDate.of(2024, 11, 20); // Start from 20th November 2024
        for (int i = 0; i < 10; i++) {

            LocalDate date = startDate.plusDays(i);
            insertSolarEnergyData(location, date, energyOutput, yieldPerKW, yieldEfficiency);
        }
    }

    // Updated method to accept a specific date
    private void insertSolarEnergyData(String location, LocalDate date, double outputKWh, double yield, double yieldEfficiency) {
        String insertQuery = "INSERT INTO solar_energy_data (location, date, output_kWh, yield, yield_efficiency, totalCapacity, status) " +
                "VALUES (?, ?, ?, ?, ?, ?, 'calculated') " +
                "ON DUPLICATE KEY UPDATE " +
                "output_kWh = VALUES(output_kWh), " +
                "yield = VALUES(yield), " +
                "yield_efficiency = VALUES(yield_efficiency), " +
                "totalCapacity = VALUES(totalCapacity), " +
                "status = 'calculated'";

        DatabaseConnection conn = new DatabaseConnection();
        Connection connectDB = conn.getConnection();

        if (connectDB == null) {
            System.err.println("Database connection failed. Unable to store solar energy data.");
            return;
        }

        try (PreparedStatement pstmt = connectDB.prepareStatement(insertQuery)) {
            pstmt.setString(1, location);
            pstmt.setDate(2, Date.valueOf(date)); // Convert LocalDate to SQL Date
            pstmt.setDouble(3, outputKWh);
            pstmt.setDouble(4, yield);
            pstmt.setDouble(5, yieldEfficiency);
            pstmt.setFloat(6, getSystemCapacity());

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Solar energy data stored successfully for location: " + location + " on date: " + date);
            }

        } catch (SQLException e) {
            System.err.println("Error inserting solar energy data: " + e.getMessage());
        }
    }




    @Override
    public void setSystemCapacity(float systemCapacity) {
        super.setSystemCapacity(systemCapacity);
    }

    @Override
    public void setNumPanels(int panelss) {
        super.setNumPanels(panelss);
    }

    public void setUV(double uvv) {
        UV= uvv;
    }

    public double getUV() {
        return UV;
    }

    public double getEnergyOutput() {
        return energyOutput;
    }

    public double getYieldEfficency() {
        return yieldEfficiency;
    }

    public double getYieldPerKW() {
        return yieldPerKW;
    }
//
//    // Main Method for Example Usage
//    public static void main(String[] args) {
//        // Create an instance of SolarEnergy (using sample data)
//        SolarEnergy solarEnergy = new SolarEnergy(1, 5.0f, 20, "Karachi");
//
//        // Calculate and display energy output
//        solarEnergy.CalculateEnergy();
//    }
}
