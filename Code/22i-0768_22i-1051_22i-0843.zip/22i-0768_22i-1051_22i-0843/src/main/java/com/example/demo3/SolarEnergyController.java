

package com.example.demo3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class SolarEnergyController implements Initializable {
    @FXML
    private Label energyProduced;

    @FXML
    private Label energyYield;

    @FXML
    private Label uvIndex;

    @FXML
    private Label cloudCover;

    @FXML
    private PieChart energyPieChart;

    @FXML
    private Label statusLabel;

    @FXML
    private Button refreshButton;

    @FXML
    private Button settingsButton;

    @FXML
    private Button exportButton;

    @FXML
    private Button returnButton;

    @FXML
    private Button comparisonButton;








    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialize the pie chart with default values
       // updateUI(0.0, 0.0, 0.0, 0.0);
        User user= Session.getLoggedInUser();
        System.out.println(user.getCity());
        SolarEnergy solarEnergy = new SolarEnergy(1,4.5f, 15, user.getCity());
        // Calculate and display energy output
        solarEnergy.CalculateEnergy(user.getCity());

        solarEnergy.calculateEnergyForDates(user.getCity());
        updateUI(solarEnergy.getEnergyOutput(), solarEnergy.getYieldEfficency(), solarEnergy.getUV(), 20);
        System.out.println(solarEnergy.getUV());
        System.out.println(solarEnergy.getNumPanels());
        // Add button handlers
        refreshButton.setOnAction(event -> handleRefresh());
        settingsButton.setOnAction(event -> handleSettings());
        exportButton.setOnAction(event -> handleExport());
    }

    // Method to update the UI with the current data
    public void updateUI(double energyProducedValue, double energyYieldPercentage,
                         double uvValue, double cloudCoverValue) {
        // Update energy produced
        energyProduced.setText(String.format("%.2f kWh", energyProducedValue));

        // Update energy yield percentage
        energyYield.setText(String.format("%.2f%%", energyYieldPercentage));

        // Update UV index
        uvIndex.setText(String.format("%.2f", uvValue));

        // Update cloud cover
        cloudCover.setText(String.format("%.2f%%", cloudCoverValue));

        // Update Pie chart with energy yield data
        energyPieChart.getData().clear();
        energyPieChart.getData().addAll(
                new PieChart.Data("Energy Used", energyYieldPercentage),
                new PieChart.Data("Energy Available", 100 - energyYieldPercentage)
        );

        // Update status
        statusLabel.setText("Last updated: Just now");
    }

    private void handleRefresh() {

        // Add refresh logic here
        System.out.println("Refresh clicked");
    }

    private void handleSettings() {
        // Add settings logic here
        System.out.println("Settings clicked");
    }

    private void handleExport() {
        // Add export logic here
        System.out.println("Export clicked");
    }


    @FXML
    private void BacktoDashboard() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("dashboard.fxml"));
        Parent root = null;
        try {
            root = loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stage = (Stage) returnButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void handleComparison(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("comparesolarvgrid.fxml"));
        Parent root = null;
        try {
            root = loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stage = (Stage) returnButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();

        }

}