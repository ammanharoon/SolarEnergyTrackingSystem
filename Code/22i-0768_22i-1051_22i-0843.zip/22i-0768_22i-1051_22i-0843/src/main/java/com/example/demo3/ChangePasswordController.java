package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;

import java.io.IOException;

public class ChangePasswordController {

    @FXML
    private PasswordField oldPasswordField;

    @FXML
    private PasswordField newPasswordField;

    @FXML
    private PasswordField confirmPasswordField;

    @FXML
    private Label errorMessageLabel;

    @FXML
    private Button saveButton;


    @FXML
    private Button cancelButton;

    // This method is triggered when the "Save Changes" button is clicked
    @FXML
    private void handleSaveChanges() {
        String oldPassword = oldPasswordField.getText().trim();
        String newPassword = newPasswordField.getText().trim();
        String confirmPassword = confirmPasswordField.getText().trim();

        // Validate the input
        if (oldPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            errorMessageLabel.setText("All fields are required!");
            return;
        }

        // Check if the old password matches (you should check against your database or saved data)


        // Check if the new password and confirm password match
        if (!newPassword.equals(confirmPassword)) {
            errorMessageLabel.setText("New password and confirmation do not match.");
            return;
        }


        User curruser= Session.getLoggedInUser();
        System.out.println(curruser.getUsername());
        if (curruser.getPassword().equals(newPassword)) { // Replace with actual logic to validate old username
            errorMessageLabel.setText("Old password does is same as old.");
            return;
        }

       UserRepository user= new UserRepository();
       user.updatePassword(curruser.getUsername(), newPassword);


        System.out.println("Password changed successfully to: " + newPassword);

        // Close the window after saving

    }

    @FXML
    private void handleCancel() {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("manageuserprofile.fxml"));
            Parent root = null;
            try {
                root = loader.load();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = (Stage) cancelButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        }


    // Helper method to close the window

}
