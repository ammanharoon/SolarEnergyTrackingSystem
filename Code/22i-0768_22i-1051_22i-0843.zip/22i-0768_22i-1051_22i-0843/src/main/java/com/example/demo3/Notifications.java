package com.example.demo3;

public class Notifications {

    private boolean emailNotification;
    private boolean smsNotification;
    private boolean appNotification;
    private boolean status=false;

    // Constructor to initialize the preferences
    public Notifications(boolean emailNotification, boolean smsNotification, boolean appNotification) {
        this.emailNotification = emailNotification;
        this.smsNotification = smsNotification;
        this.appNotification = appNotification;

    }

    // Getters and Setters
    public boolean isEmailNotification() {
        return emailNotification;
    }

    public void setEmailNotification(boolean emailNotification) {
        this.emailNotification = emailNotification;
    }

    public boolean isSmsNotification() {
        return smsNotification;
    }

    public void setSmsNotification(boolean smsNotification) {
        this.smsNotification = smsNotification;
    }

    public boolean isAppNotification() {
        return appNotification;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public boolean isStatus(boolean b) {
        return status;
    }

    public void setAppNotification(boolean appNotification) {
        this.appNotification = appNotification;
    }

    // You can also add other utility methods to update or reset preferences if necessary
    public void resetPreferences() {
        this.emailNotification = false;
        this.smsNotification = false;
        this.appNotification = false;
    }

    @Override
    public String toString() {
        return "Notifications [Email=" + emailNotification + ", SMS=" + smsNotification + ", App=" + appNotification + "]";
    }
}
