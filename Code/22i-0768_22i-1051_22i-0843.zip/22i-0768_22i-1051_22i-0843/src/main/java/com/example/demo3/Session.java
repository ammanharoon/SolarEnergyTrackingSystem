package com.example.demo3;


public class Session {
    private static User loggedInUser;
    private static SolarDevice LoggedinDevice;
    public static void setLoggedInUser(User user) {
        loggedInUser = user;
    }

    public static User getLoggedInUser() {
        return loggedInUser;
    }

    public static SolarDevice getLoggedinDevice() {
        return LoggedinDevice;
    }

    public static void setLoggedinDevice(SolarDevice loggedinDevice) {
        LoggedinDevice = loggedinDevice;
    }
}
