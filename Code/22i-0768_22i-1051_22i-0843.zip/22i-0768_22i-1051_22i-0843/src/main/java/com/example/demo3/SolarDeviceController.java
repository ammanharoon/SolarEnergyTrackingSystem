package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.*;

public class SolarDeviceController{

    @FXML
    private TextField systemCapacityField;

    @FXML
    private TextField numPanelsField;

    @FXML
    private TextField locationField;

    @FXML
    private Label messageLabel;

    @FXML
    private Button submitButton;

    @FXML
    private Button backButton;

    // Handle solar device registration
    /*
    @FXML
    private void handleDeviceRegistration() {
        // Get the values from input fields
        String systemCapacity = systemCapacityField.getText();
        String numPanels = numPanelsField.getText();
        String location = locationField.getText();

        // Validate the input fields
        if (systemCapacity.isEmpty() || numPanels.isEmpty() || location.isEmpty()) {
            messageLabel.setText("Please fill in all fields.");
            return;
        }

        try {
            // Convert system capacity and number of panels to proper types (validation can be added here)
            double capacity = Double.parseDouble(systemCapacity);
            int panels = Integer.parseInt(numPanels);



            String sql = "INSERT INTO solar_devices (system_capacity, num_panels, location) VALUES (?, ?, ?)";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setDouble(1, capacity);
            preparedStatement.setInt(2, panels);
            preparedStatement.setString(3, location);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                messageLabel.setText("Solar device registered successfully.");
                messageLabel.setStyle("-fx-text-fill: green;");
            } else {
                messageLabel.setText("Error registering solar device.");
            }

            connection.close();
        } catch (SQLException e) {
            messageLabel.setText("Database error: " + e.getMessage());
        } catch (NumberFormatException e) {
            messageLabel.setText("Please enter valid numbers for capacity and panels.");
        }
    }


     */

    @FXML
    private void handleRegisterSolarDevice() throws SQLException {
        // Collect form inputs
        int useride = 0;
        String username = Session.getLoggedInUser().getUsername();
        String query = "SELECT id FROM users WHERE username = ?";
             DatabaseConnection con = new DatabaseConnection();
             Connection connectDB = con.getConnection();
             try(PreparedStatement stmt = connectDB.prepareStatement(query))  {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                 useride= rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        float systemCapacity = Float.parseFloat(systemCapacityField.getText());
        int numPanels = Integer.parseInt(numPanelsField.getText());
        String location = locationField.getText();

        // Create SolarDevice object
        SolarDevice device = new SolarDevice(useride, systemCapacity, numPanels, location);

        // Pass to database handler for insertion
        SolarDeviceDatabaseHandler.insertDevice(device);
    }

    // Handle the back button action to go back to the dashboard
    @FXML
    private void backToDashboardAction() {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
        Parent root = null;
        try {
            root = loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}
