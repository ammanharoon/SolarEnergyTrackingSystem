package com.example.demo3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class SolarEnergyDatabase {
    private Connection conn; // Database connection

//    // Constructor to initialize database connection
//    public SolarEnergyDatabase(Connection conn) {
//        this.conn = conn;
//    }

    // Business Logic Layer Methods

    public void processCurrentWeatherData(String location, double latitude, double longitude) {
        // Get weather data from Weather class
        double uvIndex = Weather.getSolarPotential(latitude, longitude);
        double cloudCover = 20.0; // Default or from API
        double sunlightHours = Weather.calculateEffectiveSunlightHours(uvIndex, cloudCover);

        // Insert into database
        insertWeatherData(location, latitude, longitude, sunlightHours, uvIndex, cloudCover);
    }

    public void processFuturePrediction(String location, String date) {

    }

    // Database Layer Methods

    private void insertWeatherData(String location, double latitude, double longitude,
                                   double sunlightHours, double uvIndex, double cloudCover) {

        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        if (connectDB == null) {
            showError("Database connection failed. Please try again later.");

        }
        try {
            String sql = "INSERT INTO weather_data (location, latitude, longitude, " +
                    "sunlight_hours, uv_index, cloud_cover) VALUES (?, ?, ?, ?, ?, ?)";

            try (PreparedStatement pstmt = connectDB.prepareStatement(sql)) {
                pstmt.setString(1, location);
                pstmt.setDouble(2, latitude);
                pstmt.setDouble(3, longitude);
                pstmt.setDouble(4, sunlightHours);
                pstmt.setDouble(5, uvIndex);
                pstmt.setDouble(6, cloudCover);

                pstmt.executeUpdate();
                System.out.println("Weather data inserted successfully for " + location);
            }
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        }
    }

    private void showError(String s) {
    }

    private void insertWeatherPrediction(String location, String date, Map<String, Double> prediction) {
        try {
            String sql = "INSERT INTO weather_predictions (location, prediction_date, " +
                    "sunlight_hours, uv_index, cloud_cover) VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, location);
                pstmt.setDate(2, java.sql.Date.valueOf(date));
                pstmt.setDouble(3, prediction.get("sunlightHours"));
                pstmt.setDouble(4, prediction.get("uvIndex"));
                pstmt.setDouble(5, prediction.get("cloudCover"));

                pstmt.executeUpdate();
                System.out.println("Weather prediction inserted successfully for " + location + " on " + date);
            }
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        }
    }

    // Query Methods;




    public Map<String, Double> getCurrentWeatherData(String location) {
        Map<String, Double> weatherData = new HashMap<>();
        try {
            String sql = "SELECT * FROM weather_data WHERE location = ? ";

            DatabaseConnection conne = new DatabaseConnection();
            Connection connectDB = conne.getConnection();
            try (PreparedStatement pstmt = connectDB.prepareStatement(sql)) {
                pstmt.setString(1, location);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    weatherData.put("sunlightHours", rs.getDouble("sunlight_hours"));
                    weatherData.put("uvIndex", rs.getDouble("uv_index"));
                    weatherData.put("cloudCover", rs.getDouble("cloud_cover"));
                    weatherData.put("latitude", rs.getDouble("latitude"));
                    weatherData.put("longitude", rs.getDouble("longitude"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Query error: " + e.getMessage());
        }
        return weatherData;
    }

    public Map<String, Double> getPredictedWeather(String location, String date) {
        Map<String, Double> prediction = new HashMap<>();
        try {
            String sql = "SELECT * FROM weather_predictions WHERE location = ? " +
                    "AND prediction_date = ?";

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, location);
                pstmt.setDate(2, java.sql.Date.valueOf(date));
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    prediction.put("sunlightHours", rs.getDouble("sunlight_hours"));
                    prediction.put("uvIndex", rs.getDouble("uv_index"));
                    prediction.put("cloudCover", rs.getDouble("cloud_cover"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Query error: " + e.getMessage());
        }
        return prediction;
    }

    // Utility Methods

    public boolean checkLocationExists(String location) {
        try {
            String sql = "SELECT COUNT(*) FROM weather_data WHERE location = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, location);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.err.println("Query error: " + e.getMessage());
        }
        return false;
    }










}

// Usage Example:
/*
public static void main(String[] args) {
   // Assuming you have a DatabaseConnection class that provides the connection
   Connection conn = DatabaseConnection.getConnection();
   SolarDatabaseLogic solarDB = new SolarDatabaseLogic(conn);

   // Process current weather
   solarDB.processCurrentWeatherData("Karachi", 24.8607, 67.0011);

   // Process future prediction
   solarDB.processFuturePrediction("Karachi", "2024-07-15");

   // Get current weather data
   Map<String, Double> currentWeather = solarDB.getCurrentWeatherData("Karachi");
   System.out.println("Current Sunlight Hours: " + currentWeather.get("sunlightHours"));

   // Get predicted weather
   Map<String, Double> prediction = solarDB.getPredictedWeather("Karachi", "2024-07-15");
   System.out.println("Predicted Sunlight Hours: " + prediction.get("sunlightHours"));
}
*/