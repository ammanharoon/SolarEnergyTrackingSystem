module com.example.demo3 {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires java.sql;
    requires mysql.connector.j;
    requires org.json;


    opens com.example.demo3 to javafx.fxml;
    exports com.example.demo3;
}